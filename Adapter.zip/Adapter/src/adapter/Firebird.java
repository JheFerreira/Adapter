/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

/**
 *
 * @author Jéssica Ferreira
 */
public class Firebird {
    
    public void FirebirdCarregarPerfilUsuario (String usuario){
        System.out.println("Tipo de usuario" + usuario);
        
    }
    public void FirebirdTipoTransacao (String operacao){
        System.out.println("Banco de Dados Firebird de transação Única");
    }
    
}
