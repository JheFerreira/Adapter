/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

/**
 *
 * @author Jéssica Ferreira
 */
public class Firebirdusuarioadapter  extends Firebird implements BancoDeDadosAlvo {

    @Override
    public void carregarPerfilUsuario(String usuario) {
        this.FirebirdCarregarPerfilUsuario(usuario);
    }

    @Override
    public void definirTipoOperacao(String operacao) {
       this.FirebirdTipoTransacao(operacao);
    }

   
    
}
