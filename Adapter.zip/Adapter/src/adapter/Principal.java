/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

/**
 *
 * @author Jéssica Ferreira
 */
public class Principal {



    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //String perfilUsuario = "\nFirebird";


        /*BancoDeDadosAlvo usuario1 = new Firebirdusuarioadapter();
        usuario1.carregarPerfilUsuario(perfilUsuario);
        usuario1.definirTipoOperacao(perfilUsuario);*/

        String perfilUsuario = "\nMySQL";
        
        
        BancoDeDadosAlvo usuario2 = new MySQLUsuarioAdapter();
        usuario2.carregarPerfilUsuario(perfilUsuario);
        usuario2.definirTipoOperacao(perfilUsuario);
        

        /*String perfilUsuario = "Paradoxusuarioadapter";
        BancoDeDadosAlvo usuario3 = new Paradoxusuarioadapter();
        usuario3.carregarPerfilUsuario(perfilUsuario);
        usuario3.definirTipoOperacao(perfilUsuario);
        }*/

    }
    
}
