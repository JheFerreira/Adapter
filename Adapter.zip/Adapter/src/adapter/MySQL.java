/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

/**
 *
 * @author Jéssica Ferreira
 */
public class MySQL {
    
    public void MySQLCarregarPerfilUsuario ( String usuario){
        System.out.println("Tipo de usuario" + usuario);
        
    }
    public void MySQLTipoTransacao (String operacao){
        System.out.println("Banco de Dados MySQL de múltiplas transações");
    }
    
}
